import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// TODO: Replace with your actual Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBNktuUmrYdpfjsVfknBzieEMEFojvmmMI",
  authDomain: "yojana-dc626.firebaseapp.com",
  projectId: "yojana-dc626",
  storageBucket: "yojana-dc626.firebasestorage.app",
  messagingSenderId: "282049109815",
  appId: "1:282049109815:web:5f31ebb2f4f3f090d0c4b2",
  measurementId: "G-XNZDFT48FD"
};


const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
