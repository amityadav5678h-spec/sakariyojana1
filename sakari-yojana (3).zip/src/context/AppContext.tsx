import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Language, UserProfile, TRANSLATIONS } from '../types';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  userProfile: UserProfile | null;
  setUserProfile: (profile: UserProfile | null) => void;
  t: (key: keyof typeof TRANSLATIONS.en) => string;
  translate: (en: string, hi?: string) => string;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [language, setLanguage] = useState<Language>('en');
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);

  const t = (key: keyof typeof TRANSLATIONS.en) => {
    return TRANSLATIONS[language][key] || TRANSLATIONS['en'][key] || key;
  };

  const translate = (en: string, hi?: string) => {
    if (language === 'hi' && hi) return hi;
    return en;
  };

  return (
    <AppContext.Provider value={{ language, setLanguage, userProfile, setUserProfile, t, translate }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
