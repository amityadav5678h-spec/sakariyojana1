export interface Scheme {
  id?: string; // Changed to string for Firestore ID
  title_en: string;
  title_hi?: string;
  description_en: string;
  description_hi?: string;
  eligibility_en: string;
  eligibility_hi?: string;
  benefits_en: string;
  benefits_hi?: string;
  documents_en: string;
  documents_hi?: string;
  process_en: string;
  process_hi?: string;
  min_age?: number;
  max_age?: number;
  gender: 'Male' | 'Female' | 'Other' | 'All';
  category: string[];
  occupation: string[];
  state: string;
  is_active: boolean;
  status: 'draft' | 'published';
  source_url?: string;
  apply_link?: string;
  last_updated?: string;
  rating?: number;
}

export interface UserProfile {
  name: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  category: string;
  occupation: string;
  state: string;
}

export type Language = 'en' | 'hi';

export const STATES = [
  'All India', 'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Goa', 'Gujarat', 'Haryana',
  'Himachal Pradesh', 'Jharkhand', 'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya',
  'Mizoram', 'Nagaland', 'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura',
  'Uttar Pradesh', 'Uttarakhand', 'West Bengal', 'Andaman and Nicobar Islands', 'Chandigarh',
  'Dadra and Nagar Haveli and Daman and Diu', 'Lakshadweep', 'Delhi', 'Puducherry', 'Ladakh', 'Jammu and Kashmir'
];

export const CATEGORIES = [
  'General', 
  'OBC', 
  'SC', 
  'ST', 
  'EWS',
  'Minority', 
  'Muslim', 
  'Sikh', 
  'Christian', 
  'Other caste/religion groups'
];

export const OCCUPATIONS = [
  'Farmer', 
  'Student', 
  'Self-Employed', 
  'Salaried', 
  'Startup Founder', 
  'Unemployed', 
  'Laborer', 
  'Business Owner', 
  'Homemaker', 
  'Senior Citizen'
];

export const TRANSLATIONS = {
  en: {
    welcome: 'Welcome to Sakari Yojana',
    getStarted: 'Get Started',
    selectLanguage: 'Select Language',
    selectState: 'Select Your State',
    state: 'State',
    userDetails: 'Tell us about yourself',
    name: 'Name',
    age: 'Age',
    gender: 'Gender',
    category: 'Category',
    occupation: 'Occupation',
    submit: 'Find Schemes',
    dashboard: 'Dashboard',
    search: 'Search schemes...',
    filter: 'Filter',
    viewDetails: 'View Details',
    applyNow: 'Apply Now',
    source: 'Official Source',
    noSchemes: 'No schemes found matching your criteria.',
    adminLogin: 'Admin Login',
    username: 'Username',
    password: 'Password',
    login: 'Login',
    logout: 'Logout',
    createScheme: 'Create New Scheme',
    editScheme: 'Edit Scheme',
    draft: 'Draft',
    published: 'Published',
    active: 'Active',
    inactive: 'Inactive',
    aiDraft: 'Draft with AI',
    generating: 'Generating...',
    save: 'Save',
    cancel: 'Cancel',
    delete: 'Delete',
    confirmDelete: 'Are you sure you want to delete this scheme?',
    home: 'Home',
    about: 'About Us',
    contact: 'Contact Us',
    privacy: 'Privacy Policy',
    disclaimer: 'Disclaimer',
    copyright: '© 2026 Sakari Yojana. Not a government website.',
    male: 'Male',
    female: 'Female',
    other: 'Other',
    all: 'All',
  },
  hi: {
    welcome: 'सरकारी योजना में आपका स्वागत है',
    getStarted: 'शुरू करें',
    selectLanguage: 'भाषा चुनें',
    selectState: 'अपना राज्य चुनें',
    state: 'राज्य',
    userDetails: 'अपने बारे में बताएं',
    name: 'नाम',
    age: 'आयु',
    gender: 'लिंग',
    category: 'श्रेणी',
    occupation: 'व्यवसाय',
    submit: 'योजनाएं खोजें',
    dashboard: 'डैशबोर्ड',
    search: 'योजनाएं खोजें...',
    filter: 'फ़िल्टर',
    viewDetails: 'विवरण देखें',
    applyNow: 'अभी आवेदन करें',
    source: 'आधिकारिक स्रोत',
    noSchemes: 'आपके मानदंडों से मेल खाने वाली कोई योजना नहीं मिली।',
    adminLogin: 'एडमिन लॉगिन',
    username: 'उपयोगकर्ता नाम',
    password: 'पासवर्ड',
    login: 'लॉगिन',
    logout: 'लॉगआउट',
    createScheme: 'नई योजना बनाएं',
    editScheme: 'योजना संपादित करें',
    draft: 'ड्राफ्ट',
    published: 'प्रकाशित',
    active: 'सक्रिय',
    inactive: 'निष्क्रिय',
    aiDraft: 'AI के साथ ड्राफ्ट करें',
    generating: 'उत्पन्न हो रहा है...',
    save: 'सहेजें',
    cancel: 'रद्द करें',
    delete: 'हटाएं',
    confirmDelete: 'क्या आप वाकई इस योजना को हटाना चाहते हैं?',
    home: 'होम',
    about: 'हमारे बारे में',
    contact: 'संपर्क करें',
    privacy: 'गोपनीयता नीति',
    disclaimer: 'अस्वीकरण',
    copyright: '© 2026 सरकारी योजना। यह सरकारी वेबसाइट नहीं है।',
    male: 'पुरुष',
    female: 'महिला',
    other: 'अन्य',
    all: 'सभी',
  }
};
