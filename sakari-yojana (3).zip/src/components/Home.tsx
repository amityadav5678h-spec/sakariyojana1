import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { STATES, CATEGORIES, OCCUPATIONS } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronRight, Check } from 'lucide-react';

export default function Home() {
  const { t, setLanguage, setUserProfile, userProfile } = useApp();
  const navigate = useNavigate();
  const [step, setStep] = useState<'welcome' | 'language' | 'state' | 'form'>('welcome');
  
  // Form State
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    gender: '',
    category: '',
    occupation: '',
    state: ''
  });

  const handleStart = () => setStep('language');

  const handleLanguageSelect = (lang: 'en' | 'hi') => {
    setLanguage(lang);
    setStep('state');
  };

  const handleStateSelect = (state: string) => {
    setFormData({ ...formData, state });
    setStep('form');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setUserProfile({
      name: formData.name,
      age: parseInt(formData.age),
      gender: formData.gender as any,
      category: formData.category,
      occupation: formData.occupation,
      state: formData.state
    });
    navigate('/dashboard');
  };

  // Animation variants
  const pageVariants = {
    initial: { opacity: 0, x: 20 },
    in: { opacity: 1, x: 0 },
    out: { opacity: 0, x: -20 }
  };

  const pageTransition = {
    type: 'tween' as const,
    ease: 'easeInOut' as const,
    duration: 0.5
  };

  if (step === 'welcome') {
    return (
      <div className="relative min-h-[calc(100vh-4rem)] w-full overflow-hidden bg-slate-900 flex flex-col justify-center">
        {/* Background Image with Overlay */}
        <div 
          className="absolute inset-0 bg-cover bg-center z-0"
          style={{ 
            backgroundImage: 'url("https://images.unsplash.com/photo-1524492412937-b28074a5d7da?ixlib=rb-4.0.3&auto=format&fit=crop&w=2071&q=80")', // Gateway of India placeholder
            filter: 'blur(4px)',
            opacity: 0.2
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-slate-900/90 z-10" />

        <div className="relative z-20 flex-grow flex flex-col items-center justify-center text-center px-4 py-12">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-4xl md:text-6xl font-bold text-white mb-6 tracking-tight"
          >
            Sakari Yojana
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-lg md:text-xl text-slate-200 mb-10 max-w-2xl"
          >
            Find the right government schemes for you. Simple, fast, and easy.
          </motion.p>
          <motion.button
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.6 }}
            onClick={handleStart}
            className="bg-emerald-600 hover:bg-emerald-500 text-white text-lg font-semibold py-4 px-10 rounded-full shadow-lg hover:shadow-emerald-500/30 transition-all transform hover:-translate-y-1 active:scale-95 flex items-center gap-2"
          >
            Get Started <ChevronRight size={20} />
          </motion.button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100dvh-64px)] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 bg-slate-50">
      <div className="max-w-md w-full space-y-8 bg-white p-8 rounded-2xl shadow-xl border border-slate-100">
        <AnimatePresence mode="wait">
          {step === 'language' && (
            <motion.div
              key="language"
              initial="initial" animate="in" exit="out" variants={pageVariants} transition={pageTransition}
              className="space-y-6"
            >
              <h2 className="text-3xl font-bold text-center text-slate-900">Select Language</h2>
              <p className="text-center text-slate-500">Choose your preferred language</p>
              <div className="grid grid-cols-1 gap-4 mt-8">
                <button
                  onClick={() => handleLanguageSelect('en')}
                  className="flex items-center justify-between p-4 border-2 border-slate-200 rounded-xl hover:border-emerald-500 hover:bg-emerald-50 transition-all group"
                >
                  <span className="text-lg font-medium text-slate-700 group-hover:text-emerald-700">English</span>
                  <div className="w-6 h-6 rounded-full border-2 border-slate-300 group-hover:border-emerald-500 flex items-center justify-center">
                    <div className="w-3 h-3 bg-emerald-500 rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </button>
                <button
                  onClick={() => handleLanguageSelect('hi')}
                  className="flex items-center justify-between p-4 border-2 border-slate-200 rounded-xl hover:border-emerald-500 hover:bg-emerald-50 transition-all group"
                >
                  <span className="text-lg font-medium text-slate-700 group-hover:text-emerald-700">हिंदी (Hindi)</span>
                  <div className="w-6 h-6 rounded-full border-2 border-slate-300 group-hover:border-emerald-500 flex items-center justify-center">
                    <div className="w-3 h-3 bg-emerald-500 rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </button>
              </div>
            </motion.div>
          )}

          {step === 'state' && (
            <motion.div
              key="state"
              initial="initial" animate="in" exit="out" variants={pageVariants} transition={pageTransition}
              className="space-y-6"
            >
              <h2 className="text-2xl font-bold text-center text-slate-900">{t('selectState')}</h2>
              <div className="space-y-2 max-h-96 overflow-y-auto pr-2 custom-scrollbar">
                {STATES.map((st) => (
                  <button
                    key={st}
                    onClick={() => handleStateSelect(st)}
                    className="w-full text-left px-4 py-3 rounded-lg hover:bg-slate-100 text-slate-700 hover:text-emerald-700 transition-colors border border-transparent hover:border-slate-200"
                  >
                    {st}
                  </button>
                ))}
              </div>
            </motion.div>
          )}

          {step === 'form' && (
            <motion.div
              key="form"
              initial="initial" animate="in" exit="out" variants={pageVariants} transition={pageTransition}
              className="space-y-6"
            >
              <h2 className="text-2xl font-bold text-center text-slate-900">{t('userDetails')}</h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">{t('name')}</label>
                  <input
                    type="text"
                    required
                    className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">{t('age')}</label>
                  <input
                    type="number"
                    required
                    min="0"
                    max="120"
                    className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                    value={formData.age}
                    onChange={(e) => setFormData({...formData, age: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">{t('gender')}</label>
                  <select
                    required
                    className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                    value={formData.gender}
                    onChange={(e) => setFormData({...formData, gender: e.target.value})}
                  >
                    <option value="">Select Gender</option>
                    <option value="Male">{t('male')}</option>
                    <option value="Female">{t('female')}</option>
                    <option value="Other">{t('other')}</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">{t('category')}</label>
                  <select
                    required
                    className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                    value={formData.category}
                    onChange={(e) => setFormData({...formData, category: e.target.value})}
                  >
                    <option value="">Select Category</option>
                    {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">{t('occupation')}</label>
                  <select
                    required
                    className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                    value={formData.occupation}
                    onChange={(e) => setFormData({...formData, occupation: e.target.value})}
                  >
                    <option value="">Select Occupation</option>
                    {OCCUPATIONS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>

                <button
                  type="submit"
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-4 rounded-xl shadow-md hover:shadow-lg transition-all transform hover:-translate-y-0.5 mt-6"
                >
                  {t('submit')}
                </button>
              </form>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
