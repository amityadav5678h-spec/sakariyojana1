import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Scheme, STATES, CATEGORIES, OCCUPATIONS } from '../types';
import { 
  LayoutDashboard, 
  PlusCircle, 
  FileText, 
  LogOut, 
  Star, 
  Search, 
  Edit, 
  Trash2, 
  Save, 
  X,
  Menu,
  Sparkles
} from 'lucide-react';
import { db } from '../firebase';
import { collection, getDocs, addDoc, updateDoc, deleteDoc, doc, query, orderBy } from 'firebase/firestore';

export default function AdminDashboard() {
  const { t } = useApp();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'dashboard' | 'add' | 'view'>('dashboard');
  const [schemes, setSchemes] = useState<Scheme[]>([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  
  // Edit State
  const [editingScheme, setEditingScheme] = useState<Partial<Scheme> | null>(null);
  
  // Search & Filter State
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('All');
  const [filterOccupation, setFilterOccupation] = useState('All');

  // AI State
  const [isAIProcessing, setIsAIProcessing] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');

  useEffect(() => {
    checkAuth();
    fetchSchemes();
  }, []);

  const checkAuth = async () => {
    try {
      const res = await fetch('/api/admin/me');
      if (!res.ok) {
        navigate('/admin/login');
      }
    } catch (err) {
      navigate('/admin/login');
    }
  };

  const fetchSchemes = async () => {
    try {
      const schemesCollection = collection(db, 'schemes');
      // In production, you might want to order by date, but requires an index
      const q = query(schemesCollection); 
      const snapshot = await getDocs(q);
      const schemeList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Scheme));
      setSchemes(schemeList);
    } catch (err) {
      console.error("Error fetching schemes:", err);
    }
  };

  const handleLogout = async () => {
    await fetch('/api/admin/logout', { method: 'POST' });
    navigate('/admin/login');
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this scheme?')) return;
    try {
      await deleteDoc(doc(db, 'schemes', id));
      fetchSchemes();
    } catch (err) {
      console.error("Error deleting scheme:", err);
      alert("Failed to delete scheme");
    }
  };

  const handleSaveScheme = async (schemeData: Partial<Scheme>) => {
    try {
      const dataToSave = {
        ...schemeData,
        status: 'published',
        is_active: true,
        last_updated: new Date().toISOString()
      };

      if (schemeData.id) {
        // Update
        const schemeRef = doc(db, 'schemes', schemeData.id);
        // Remove id from data before updating
        const { id, ...updateData } = dataToSave;
        await updateDoc(schemeRef, updateData as any);
        alert('Scheme updated successfully!');
      } else {
        // Add
        await addDoc(collection(db, 'schemes'), dataToSave);
        alert('Scheme added successfully!');
      }
      
      fetchSchemes();
      setEditingScheme(null);
      setActiveTab('view');
    } catch (err) {
      console.error("Error saving scheme:", err);
      alert('Error saving scheme.');
    }
  };

  const handleAIDraft = async () => {
    if (!aiPrompt) return;
    setIsAIProcessing(true);
    try {
      const res = await fetch('/api/ai/draft', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ schemeName: aiPrompt, prompt: '' })
      });
      const data = await res.json();
      // Merge AI data with current form data
      setEditingScheme(prev => ({ ...prev, ...data }));
    } catch (err) {
      console.error(err);
      alert('AI Draft failed');
    } finally {
      setIsAIProcessing(false);
    }
  };

  // --- Components ---

  const Sidebar = () => (
    <div className={`fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 text-white transform transition-transform duration-200 ease-in-out ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:relative md:translate-x-0`}>
      <div className="p-6 border-b border-slate-800 flex justify-between items-center">
        <h2 className="text-xl font-bold">Admin Panel</h2>
        <button onClick={() => setIsSidebarOpen(false)} className="md:hidden text-slate-400 hover:text-white">
          <X size={24} />
        </button>
      </div>
      <nav className="p-4 space-y-2">
        <button 
          onClick={() => setActiveTab('dashboard')}
          className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'dashboard' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
        >
          <LayoutDashboard size={20} /> Dashboard
        </button>
        <button 
          onClick={() => { setActiveTab('add'); setEditingScheme(null); }}
          className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'add' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
        >
          <PlusCircle size={20} /> Add Scheme
        </button>
        <button 
          onClick={() => setActiveTab('view')}
          className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'view' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
        >
          <FileText size={20} /> View Schemes
        </button>
        <div className="pt-8 border-t border-slate-800 mt-8">
          <button 
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-red-400 hover:bg-slate-800 hover:text-red-300 transition-colors"
          >
            <LogOut size={20} /> Logout
          </button>
        </div>
      </nav>
    </div>
  );

  const DashboardView = () => {
    const totalSchemes = schemes.length;
    const avgRating = schemes.length > 0 
      ? (schemes.reduce((acc, s) => acc + (s.rating || 0), 0) / schemes.length).toFixed(1) 
      : '0.0';

    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold text-slate-900">Dashboard Overview</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 flex items-center gap-4">
            <div className="p-4 bg-blue-100 text-blue-600 rounded-full">
              <FileText size={32} />
            </div>
            <div>
              <p className="text-slate-500 text-sm font-medium">Total Schemes Uploaded</p>
              <p className="text-3xl font-bold text-slate-900">{totalSchemes}</p>
            </div>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 flex items-center gap-4">
            <div className="p-4 bg-yellow-100 text-yellow-600 rounded-full">
              <Star size={32} />
            </div>
            <div>
              <p className="text-slate-500 text-sm font-medium">Average Scheme Rating</p>
              <p className="text-3xl font-bold text-slate-900">{avgRating} <span className="text-sm text-slate-400 font-normal">/ 5.0</span></p>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const SchemeForm = ({ initialData }: { initialData?: Partial<Scheme> }) => {
    const [formData, setFormData] = useState<Partial<Scheme>>(initialData || {
      title_en: '',
      category: [],
      occupation: [],
      state: 'All India',
      min_age: 18,
      max_age: 60,
      rating: 5,
      description_en: '',
      benefits_en: '',
      eligibility_en: '',
      documents_en: '',
      process_en: '',
      apply_link: '',
      last_updated: new Date().toISOString().slice(0, 10),
      gender: 'All'
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      handleSaveScheme(formData);
    };

    return (
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
        <h2 className="text-2xl font-bold text-slate-900 mb-6">{initialData ? 'Edit Scheme' : 'Add New Scheme'}</h2>
        
        {/* AI Assistant */}
        {!initialData && (
          <div className="mb-8 bg-indigo-50 p-4 rounded-lg border border-indigo-100">
            <h3 className="text-indigo-900 font-semibold mb-2 flex items-center gap-2"><Sparkles size={18} /> AI Assistant</h3>
            <div className="flex gap-2">
              <input 
                type="text" 
                placeholder="Enter scheme name (e.g. PM Kisan Samman Nidhi)" 
                className="flex-grow p-2 rounded border border-indigo-200"
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
              />
              <button 
                onClick={handleAIDraft} 
                disabled={isAIProcessing}
                className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 disabled:opacity-50"
              >
                {isAIProcessing ? 'Drafting...' : 'Auto-Draft'}
              </button>
            </div>
            <p className="text-xs text-indigo-600 mt-2">AI will generate a draft based on official sources. Please review carefully.</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Scheme Name</label>
              <input 
                required 
                className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                value={formData.title_en}
                onChange={e => setFormData({...formData, title_en: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">State</label>
              <select 
                className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                value={formData.state}
                onChange={e => setFormData({...formData, state: e.target.value})}
              >
                {STATES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Category (Social Group)</label>
              <select 
                multiple 
                className="w-full p-2 border rounded-lg h-32 focus:ring-2 focus:ring-emerald-500 outline-none"
                value={Array.isArray(formData.category) ? formData.category : []}
                onChange={e => setFormData({...formData, category: Array.from(e.target.selectedOptions, o => o.value)})}
              >
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <p className="text-xs text-slate-500 mt-1">Hold Ctrl/Cmd to select multiple</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Occupation (Profession)</label>
              <select 
                multiple 
                className="w-full p-2 border rounded-lg h-32 focus:ring-2 focus:ring-emerald-500 outline-none"
                value={Array.isArray(formData.occupation) ? formData.occupation : []}
                onChange={e => setFormData({...formData, occupation: Array.from(e.target.selectedOptions, o => o.value)})}
              >
                {OCCUPATIONS.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
             <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Min Age</label>
                <input 
                  type="number" 
                  className="w-full p-2 border rounded-lg"
                  value={formData.min_age}
                  onChange={e => setFormData({...formData, min_age: parseInt(e.target.value)})}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Max Age</label>
                <input 
                  type="number" 
                  className="w-full p-2 border rounded-lg"
                  value={formData.max_age}
                  onChange={e => setFormData({...formData, max_age: parseInt(e.target.value)})}
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Scheme Rating (1-5)</label>
              <input 
                type="number" 
                min="1" max="5" step="0.1"
                className="w-full p-2 border rounded-lg"
                value={formData.rating}
                onChange={e => setFormData({...formData, rating: parseFloat(e.target.value)})}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Last Updated Date</label>
              <input 
                type="date" 
                className="w-full p-2 border rounded-lg"
                value={formData.last_updated ? formData.last_updated.slice(0, 10) : ''}
                onChange={e => setFormData({...formData, last_updated: e.target.value})}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Short Description</label>
            <textarea 
              className="w-full p-2 border rounded-lg h-20"
              value={formData.description_en}
              onChange={e => setFormData({...formData, description_en: e.target.value})}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Full Benefits</label>
              <textarea 
                className="w-full p-2 border rounded-lg h-32"
                value={formData.benefits_en}
                onChange={e => setFormData({...formData, benefits_en: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Eligibility Criteria</label>
              <textarea 
                className="w-full p-2 border rounded-lg h-32"
                value={formData.eligibility_en}
                onChange={e => setFormData({...formData, eligibility_en: e.target.value})}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Required Documents</label>
              <textarea 
                className="w-full p-2 border rounded-lg h-32"
                value={formData.documents_en}
                onChange={e => setFormData({...formData, documents_en: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">How to Apply (Steps)</label>
              <textarea 
                className="w-full p-2 border rounded-lg h-32"
                value={formData.process_en}
                onChange={e => setFormData({...formData, process_en: e.target.value})}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Official Apply Link</label>
            <input 
              type="url"
              className="w-full p-2 border rounded-lg"
              value={formData.apply_link}
              onChange={e => setFormData({...formData, apply_link: e.target.value})}
            />
          </div>

          <div className="flex justify-end gap-4 pt-4 border-t border-slate-100">
            {initialData && (
              <button 
                type="button"
                onClick={() => { setEditingScheme(null); setActiveTab('view'); }}
                className="px-6 py-2 text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
            )}
            <button 
              type="submit"
              className="px-6 py-2 bg-emerald-600 text-white font-bold rounded-lg hover:bg-emerald-700 shadow-md"
            >
              {initialData ? 'Update Scheme' : 'Add Scheme'}
            </button>
          </div>
        </form>
      </div>
    );
  };

  const ViewSchemes = () => {
    const filtered = schemes.filter(s => {
      const matchesSearch = s.title_en.toLowerCase().includes(searchTerm.toLowerCase());
      
      let matchesCategory = true;
      if (filterCategory !== 'All') {
        matchesCategory = s.category?.includes(filterCategory) || false;
      }

      let matchesOccupation = true;
      if (filterOccupation !== 'All') {
        matchesOccupation = s.occupation?.includes(filterOccupation) || false;
      }

      return matchesSearch && matchesCategory && matchesOccupation;
    });

    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold text-slate-900">View / Edit Schemes</h1>
        
        {/* Filters */}
        <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 flex flex-col md:flex-row gap-4 flex-wrap">
          <div className="relative flex-grow min-w-[200px]">
            <input 
              type="text" 
              placeholder="Search by Scheme Name..." 
              className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Search className="absolute left-3 top-2.5 text-slate-400" size={18} />
          </div>
          <select 
            className="p-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
          >
            <option value="All">All Categories</option>
            {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
          <select 
            className="p-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
            value={filterOccupation}
            onChange={(e) => setFilterOccupation(e.target.value)}
          >
            <option value="All">All Occupations</option>
            {OCCUPATIONS.map(o => <option key={o} value={o}>{o}</option>)}
          </select>
        </div>

        {/* Table */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Scheme Name</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Category</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Rating</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Last Updated</th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-slate-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {filtered.map((scheme) => (
                  <tr key={scheme.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-slate-900">{scheme.title_en}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-slate-500 flex flex-wrap gap-1">
                         {(scheme.category || []).slice(0, 2).map((c: string) => (
                            <span key={c} className="bg-slate-100 px-2 py-0.5 rounded text-xs">{c}</span>
                         ))}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center text-sm text-yellow-600">
                        <Star size={16} className="fill-current mr-1" />
                        {scheme.rating || 0}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                      {scheme.last_updated ? new Date(scheme.last_updated).toLocaleDateString() : '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button 
                        onClick={() => {
                          setEditingScheme(scheme);
                          setActiveTab('add'); // Reuse add form for editing
                        }} 
                        className="text-indigo-600 hover:text-indigo-900 mr-4"
                      >
                        <Edit size={18} />
                      </button>
                      <button 
                        onClick={() => handleDelete(scheme.id!)} 
                        className="text-red-600 hover:text-red-900"
                      >
                        <Trash2 size={18} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Mobile Sidebar Toggle */}
      <button 
        onClick={() => setIsSidebarOpen(true)}
        className="md:hidden fixed top-4 left-4 z-40 bg-slate-900 text-white p-2 rounded-lg shadow-lg"
      >
        <Menu size={24} />
      </button>

      <Sidebar />

      <main className="flex-grow p-4 md:p-8 overflow-y-auto h-screen">
        {activeTab === 'dashboard' && <DashboardView />}
        {activeTab === 'add' && <SchemeForm initialData={editingScheme || undefined} />}
        {activeTab === 'view' && <ViewSchemes />}
      </main>
    </div>
  );
}
