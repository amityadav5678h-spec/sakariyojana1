import React from 'react';
import { Link, Outlet } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Menu, X } from 'lucide-react';

export default function Layout() {
  const { t, language, setLanguage } = useApp();
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans">
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center">
              <Link to="/" className="flex items-center gap-2">
                <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white font-bold text-xl">
                  S
                </div>
                <span className="font-bold text-xl tracking-tight text-emerald-900">Sakari Yojana</span>
              </Link>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <Link to="/" className="text-slate-600 hover:text-emerald-600 transition-colors">{t('home')}</Link>
              <Link to="/about" className="text-slate-600 hover:text-emerald-600 transition-colors">{t('about')}</Link>
              <Link to="/contact" className="text-slate-600 hover:text-emerald-600 transition-colors">{t('contact')}</Link>
              <button 
                onClick={() => setLanguage(language === 'en' ? 'hi' : 'en')}
                className="px-3 py-1 rounded-full border border-slate-200 text-sm font-medium hover:bg-slate-50"
              >
                {language === 'en' ? 'हिंदी' : 'English'}
              </button>
            </div>

            <div className="md:hidden flex items-center">
              <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-slate-600 p-2">
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-slate-100">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              <Link to="/" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:text-emerald-600 hover:bg-slate-50">{t('home')}</Link>
              <Link to="/about" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:text-emerald-600 hover:bg-slate-50">{t('about')}</Link>
              <Link to="/contact" onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:text-emerald-600 hover:bg-slate-50">{t('contact')}</Link>
              <button 
                onClick={() => {
                  setLanguage(language === 'en' ? 'hi' : 'en');
                  setIsMenuOpen(false);
                }}
                className="w-full text-left block px-3 py-2 rounded-md text-base font-medium text-slate-700 hover:text-emerald-600 hover:bg-slate-50"
              >
                {language === 'en' ? 'Switch to Hindi' : 'अंग्रेजी में बदलें'}
              </button>
            </div>
          </div>
        )}
      </header>

      <main className="flex-grow">
        <Outlet />
      </main>

      <footer className="bg-slate-900 text-slate-400 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-white text-lg font-bold mb-4">Sakari Yojana</h3>
              <p className="text-sm leading-relaxed">
                {language === 'en' 
                  ? 'Connecting citizens with government schemes. Information provided here is for educational purposes only.' 
                  : 'नागरिकों को सरकारी योजनाओं से जोड़ना। यहाँ दी गई जानकारी केवल शैक्षिक उद्देश्यों के लिए है।'}
              </p>
            </div>
            <div>
              <h3 className="text-white text-lg font-bold mb-4">Links</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/about" className="hover:text-white transition-colors">{t('about')}</Link></li>
                <li><Link to="/contact" className="hover:text-white transition-colors">{t('contact')}</Link></li>
                <li><Link to="/privacy" className="hover:text-white transition-colors">{t('privacy')}</Link></li>
                <li><Link to="/disclaimer" className="hover:text-white transition-colors">{t('disclaimer')}</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-white text-lg font-bold mb-4">Legal</h3>
              <p className="text-xs mb-4">
                {language === 'en' 
                  ? 'This website is NOT an official government portal. We do not claim to be a government body.' 
                  : 'यह वेबसाइट आधिकारिक सरकारी पोर्टल नहीं है। हम सरकारी निकाय होने का दावा नहीं करते हैं।'}
              </p>
              <p className="text-xs">© 2026 Sakari Yojana</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
