import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Scheme, STATES, CATEGORIES, OCCUPATIONS } from '../types';
import { Search, Filter, ChevronDown, MapPin, Briefcase, Users, Star } from 'lucide-react';
import { db } from '../firebase';
import { collection, getDocs, query, where } from 'firebase/firestore';

export default function Dashboard() {
  const { t, language, userProfile, translate } = useApp();
  const [schemes, setSchemes] = useState<Scheme[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    state: userProfile?.state || 'All India',
    category: userProfile?.category || '',
    occupation: userProfile?.occupation || '',
    age: userProfile?.age || '',
    gender: userProfile?.gender || ''
  });
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    fetchSchemes();
  }, [filters.state]); 

  const fetchSchemes = async () => {
    setLoading(true);
    try {
      const schemesCollection = collection(db, 'schemes');
      // Basic filtering for state can be done in Firestore if indexed, 
      // but for simplicity and multiple filters, we'll fetch all and filter client-side
      // or implement basic where clauses.
      // Ideally: 
      // let q = query(schemesCollection, where("is_active", "==", true), where("status", "==", "published"));
      // if (filters.state !== 'All India') {
      //   q = query(q, where("state", "in", [filters.state, "All India"]));
      // }
      // const snapshot = await getDocs(q);
      
      // Fetching all active published schemes
      const q = query(schemesCollection, where("is_active", "==", true), where("status", "==", "published"));
      const snapshot = await getDocs(q);
      const schemeList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Scheme));
      setSchemes(schemeList);
    } catch (error) {
      console.error('Failed to fetch schemes', error);
    } finally {
      setLoading(false);
    }
  };

  // Client-side filtering for more specific attributes
  const filteredSchemes = schemes.filter(scheme => {
    // State Filter (Client side double check)
    if (filters.state !== 'All India' && scheme.state !== 'All India' && scheme.state !== filters.state) return false;

    // Search
    const title = language === 'hi' ? (scheme.title_hi || scheme.title_en) : scheme.title_en;
    if (searchTerm && !title.toLowerCase().includes(searchTerm.toLowerCase())) return false;

    // Category
    if (filters.category && scheme.category) {
      if (!scheme.category.includes(filters.category)) return false;
    }

    // Occupation
    if (filters.occupation && scheme.occupation) {
      if (!scheme.occupation.includes(filters.occupation)) return false;
    }

    // Gender
    if (filters.gender && scheme.gender !== 'All' && scheme.gender !== filters.gender) return false;

    // Age
    if (filters.age) {
      const age = Number(filters.age);
      if (scheme.min_age && age < scheme.min_age) return false;
      if (scheme.max_age && age > scheme.max_age) return false;
    }

    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header & Search */}
      <div className="mb-8 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <h1 className="text-3xl font-bold text-slate-900">{t('dashboard')}</h1>
          <div className="relative w-full md:w-96">
            <input
              type="text"
              placeholder={t('search')}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none shadow-sm"
            />
            <Search className="absolute left-3 top-3.5 text-slate-400" size={20} />
          </div>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-2 px-4 py-3 bg-white border border-slate-200 rounded-xl text-slate-700 hover:bg-slate-50 shadow-sm"
          >
            <Filter size={20} />
            {t('filter')}
            <ChevronDown size={16} className={`transform transition-transform ${showFilters ? 'rotate-180' : ''}`} />
          </button>
        </div>

        {/* Filters Panel */}
        {showFilters && (
          <div className="bg-white p-6 rounded-2xl shadow-md border border-slate-100 grid grid-cols-1 md:grid-cols-3 gap-6 animate-in fade-in slide-in-from-top-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">{t('state')}</label>
              <select
                className="w-full p-2 rounded-lg border border-slate-200"
                value={filters.state}
                onChange={(e) => setFilters({ ...filters, state: e.target.value })}
              >
                {STATES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">{t('category')}</label>
              <select
                className="w-full p-2 rounded-lg border border-slate-200"
                value={filters.category}
                onChange={(e) => setFilters({ ...filters, category: e.target.value })}
              >
                <option value="">All Categories</option>
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">{t('occupation')}</label>
              <select
                className="w-full p-2 rounded-lg border border-slate-200"
                value={filters.occupation}
                onChange={(e) => setFilters({ ...filters, occupation: e.target.value })}
              >
                <option value="">All Occupations</option>
                {OCCUPATIONS.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
          </div>
        )}
      </div>

      {/* Results */}
      {loading ? (
        <div className="flex justify-center py-20">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
        </div>
      ) : filteredSchemes.length === 0 ? (
        <div className="text-center py-20 bg-white rounded-2xl border border-dashed border-slate-300">
          <p className="text-slate-500 text-lg">{t('noSchemes')}</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredSchemes.map((scheme) => (
            <div key={scheme.id} className="bg-white rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow overflow-hidden flex flex-col">
              <div className="p-6 flex-grow">
                <div className="flex items-start justify-between mb-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${scheme.state === 'All India' ? 'bg-blue-50 text-blue-700' : 'bg-emerald-50 text-emerald-700'}`}>
                    {scheme.state}
                  </span>
                  {scheme.rating && (
                    <div className="flex items-center text-xs font-medium text-yellow-600 bg-yellow-50 px-2 py-1 rounded-full">
                      <Star size={12} className="fill-current mr-1" />
                      {scheme.rating}
                    </div>
                  )}
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-2 line-clamp-2">
                  {language === 'hi' ? (scheme.title_hi || scheme.title_en) : scheme.title_en}
                </h3>
                <p className="text-slate-600 text-sm mb-4 line-clamp-3">
                  {language === 'hi' ? (scheme.description_hi || scheme.description_en) : scheme.description_en}
                </p>
                
                <div className="space-y-2 text-xs text-slate-500">
                  <div className="flex items-center gap-2">
                    <Users size={14} />
                    <span>
                      {(scheme.category || []).slice(0, 2).join(', ')}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Briefcase size={14} />
                    <span>
                      {(scheme.occupation || []).slice(0, 2).join(', ')}
                    </span>
                  </div>
                </div>
              </div>
              <div className="p-4 bg-slate-50 border-t border-slate-100">
                <Link
                  to={`/scheme/${scheme.id}`}
                  className="block w-full text-center bg-white border border-slate-200 text-emerald-600 font-medium py-2 rounded-lg hover:bg-emerald-50 transition-colors"
                >
                  {t('viewDetails')}
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
