import React from 'react';

export const About = () => (
  <div className="max-w-3xl mx-auto px-4 py-12">
    <h1 className="text-3xl font-bold mb-6">About Us</h1>
    <p className="mb-4 text-slate-700 leading-relaxed">
      Sakari Yojana is an informational platform dedicated to simplifying government schemes for Indian citizens. 
      Our mission is to bridge the gap between government initiatives and the people who need them most.
    </p>
    <p className="mb-4 text-slate-700 leading-relaxed">
      We understand that finding accurate information about eligibility, benefits, and application processes can be difficult. 
      Our team works tirelessly to gather information from official sources and present it in an easy-to-understand format in both English and Hindi.
    </p>
    <p className="text-slate-700 leading-relaxed">
      Please note that we are a private entity and not affiliated with the Government of India or any state government.
    </p>
  </div>
);

export const Contact = () => (
  <div className="max-w-3xl mx-auto px-4 py-12">
    <h1 className="text-3xl font-bold mb-6">Contact Us</h1>
    <form className="space-y-4 bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">Name</label>
        <input type="text" className="w-full p-2 border rounded-lg" />
      </div>
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
        <input type="email" className="w-full p-2 border rounded-lg" />
      </div>
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">Message</label>
        <textarea className="w-full p-2 border rounded-lg h-32"></textarea>
      </div>
      <button className="bg-emerald-600 text-white px-6 py-2 rounded-lg hover:bg-emerald-700">Send Message</button>
    </form>
  </div>
);

export const Privacy = () => (
  <div className="max-w-3xl mx-auto px-4 py-12 prose prose-slate">
    <h1>Privacy Policy</h1>
    <p>Last updated: February 2026</p>
    <p>At Sakari Yojana, we take your privacy seriously. This Privacy Policy explains how we collect, use, and protect your information.</p>
    
    <h3>Information We Collect</h3>
    <p>We do not permanently store your personal data entered in the eligibility form. The data (name, age, occupation) is used solely within your browser session to filter relevant schemes.</p>
    
    <h3>Cookies</h3>
    <p>We use cookies to enhance your experience, such as remembering your language preference.</p>
    
    <h3>Third-Party Services</h3>
    <p>We use Google AdSense to display ads. Google may use cookies to serve ads based on your prior visits to our website or other websites.</p>
  </div>
);

export const Disclaimer = () => (
  <div className="max-w-3xl mx-auto px-4 py-12 prose prose-slate">
    <h1>Disclaimer</h1>
    <p className="font-bold text-red-600">IMPORTANT: We are NOT an official government website.</p>
    <p>Sakari Yojana is an independent informational platform. We are not associated, affiliated, authorized, endorsed by, or in any way officially connected with the Government of India or any state government.</p>
    <p>All information provided on this website is for educational and informational purposes only. While we strive to provide accurate and up-to-date information, we make no representations or warranties of any kind about the completeness, accuracy, reliability, suitability, or availability of the information.</p>
    <p>Users are strongly advised to verify all information from official government portals before applying for any scheme.</p>
  </div>
);
