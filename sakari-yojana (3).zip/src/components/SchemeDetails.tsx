import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Scheme } from '../types';
import { ArrowLeft, ExternalLink, FileText, CheckCircle, HelpCircle, Star } from 'lucide-react';
import { db } from '../firebase';
import { doc, getDoc } from 'firebase/firestore';

export default function SchemeDetails() {
  const { id } = useParams();
  const { t, language } = useApp();
  const [scheme, setScheme] = useState<Scheme | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) fetchScheme(id);
  }, [id]);

  const fetchScheme = async (schemeId: string) => {
    try {
      const docRef = doc(db, 'schemes', schemeId);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        setScheme({ id: docSnap.id, ...docSnap.data() } as Scheme);
      } else {
        console.log("No such document!");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="flex justify-center py-20"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div></div>;
  if (!scheme) return <div className="text-center py-20 text-slate-500">Scheme not found</div>;

  const title = language === 'hi' ? (scheme.title_hi || scheme.title_en) : scheme.title_en;
  const description = language === 'hi' ? (scheme.description_hi || scheme.description_en) : scheme.description_en;
  const benefits = language === 'hi' ? (scheme.benefits_hi || scheme.benefits_en) : scheme.benefits_en;
  const eligibility = language === 'hi' ? (scheme.eligibility_hi || scheme.eligibility_en) : scheme.eligibility_en;
  const documents = language === 'hi' ? (scheme.documents_hi || scheme.documents_en) : scheme.documents_en;
  const process = language === 'hi' ? (scheme.process_hi || scheme.process_en) : scheme.process_en;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Link to="/dashboard" className="inline-flex items-center text-slate-500 hover:text-emerald-600 mb-6 transition-colors">
        <ArrowLeft size={20} className="mr-2" /> Back to Dashboard
      </Link>

      <div className="bg-white rounded-2xl shadow-lg border border-slate-100 overflow-hidden">
        <div className="bg-emerald-600 p-8 text-white">
          <div className="flex flex-wrap items-center gap-4 mb-4">
            <span className="inline-block px-3 py-1 rounded-full bg-white/20 text-sm font-medium backdrop-blur-sm">
              {scheme.state}
            </span>
            {scheme.rating && (
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-yellow-400/20 text-yellow-200 text-sm font-medium backdrop-blur-sm border border-yellow-400/30">
                <Star size={14} className="mr-1 fill-current" /> {scheme.rating} / 5
              </span>
            )}
            <span className="text-xs text-emerald-100">
              Updated: {scheme.last_updated ? new Date(scheme.last_updated).toLocaleDateString() : '-'}
            </span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-4">{title}</h1>
          <p className="text-emerald-50 text-lg leading-relaxed">{description}</p>
        </div>

        <div className="p-8 space-y-8">
          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-2">
              <CheckCircle className="text-emerald-600" /> Benefits
            </h2>
            <div className="prose prose-slate max-w-none bg-slate-50 p-6 rounded-xl border border-slate-100">
              <p className="whitespace-pre-line text-slate-700">{benefits}</p>
            </div>
          </section>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <section>
              <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-2">
                <Users className="text-blue-600" size={24} /> Eligibility
              </h2>
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm h-full">
                <p className="whitespace-pre-line text-slate-700">{eligibility}</p>
                <div className="mt-4 pt-4 border-t border-slate-100 text-sm text-slate-500 space-y-2">
                  <p><strong>Age:</strong> {scheme.min_age} - {scheme.max_age} years</p>
                  <p><strong>Gender:</strong> {scheme.gender}</p>
                  <p><strong>Category:</strong> {(scheme.category || []).join(', ')}</p>
                  <p><strong>Occupation:</strong> {(scheme.occupation || []).join(', ')}</p>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-2">
                <FileText className="text-orange-600" /> Required Documents
              </h2>
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm h-full">
                <p className="whitespace-pre-line text-slate-700">{documents}</p>
              </div>
            </section>
          </div>

          <section>
            <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-2">
              <HelpCircle className="text-purple-600" /> How to Apply
            </h2>
            <div className="bg-purple-50 p-6 rounded-xl border border-purple-100">
              <p className="whitespace-pre-line text-slate-700">{process}</p>
            </div>
          </section>

          {scheme.apply_link && (
            <div className="flex justify-center pt-8">
              <a 
                href={scheme.apply_link} 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-8 py-4 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1"
              >
                Apply Now <ExternalLink size={20} />
              </a>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
