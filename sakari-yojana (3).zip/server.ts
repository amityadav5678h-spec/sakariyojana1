import express from 'express';
import { createServer as createViteServer } from 'vite';
import jwt from 'jsonwebtoken';
import cookieParser from 'cookie-parser';
import { GoogleGenAI } from '@google/genai';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-key-change-in-prod';
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

// Hardcoded Admin Credentials (as per user request)
// Username: admin1
// Password: admin5788
const ADMIN_USERNAME = 'admin1';
const ADMIN_PASSWORD = 'admin5788';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());
  app.use(cookieParser());

  // --- API Routes ---

  // Auth Middleware
  const authenticateToken = (req: any, res: any, next: any) => {
    const token = req.cookies.token;
    if (!token) return res.sendStatus(401);

    jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
      if (err) return res.sendStatus(403);
      req.user = user;
      next();
    });
  };

  // Login
  app.post('/api/admin/login', async (req, res) => {
    const { username, password } = req.body;
    
    // Simple hardcoded check for the requested credentials
    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
      const token = jwt.sign({ username: ADMIN_USERNAME, role: 'admin' }, JWT_SECRET, { expiresIn: '24h' });
      res.cookie('token', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax' });
      res.json({ message: 'Logged in' });
    } else {
      res.status(400).json({ error: 'Invalid credentials' });
    }
  });

  app.post('/api/admin/logout', (req, res) => {
    res.clearCookie('token');
    res.json({ message: 'Logged out' });
  });

  app.get('/api/admin/me', authenticateToken, (req: any, res) => {
    res.json({ user: req.user });
  });

  // AI Draft Route
  app.post('/api/ai/draft', authenticateToken, async (req, res) => {
    if (!GEMINI_API_KEY) return res.status(500).json({ error: 'Gemini API Key missing' });
    
    const { prompt, schemeName } = req.body;
    
    try {
      const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY });
      // const model = ai.models.getGenerativeModel({ model: 'gemini-2.5-flash' }); 

      const systemPrompt = `
        You are an assistant for a government scheme information portal.
        Your task is to draft structured information about a government scheme based on the user's input (Scheme Name or rough notes).
        
        Output MUST be valid JSON with the following structure:
        {
          "title_en": "Scheme Name in English",
          "title_hi": "Scheme Name in Hindi",
          "description_en": "Short description (English)",
          "description_hi": "Short description (Hindi)",
          "eligibility_en": "Detailed eligibility (English)",
          "eligibility_hi": "Detailed eligibility (Hindi)",
          "benefits_en": "Benefits (English)",
          "benefits_hi": "Benefits (Hindi)",
          "documents_en": "Required documents (English)",
          "documents_hi": "Required documents (Hindi)",
          "process_en": "Application process (English)",
          "process_hi": "Application process (Hindi)",
          "min_age": 18,
          "max_age": 60,
          "gender": "All", 
          "category": ["General", "SC", "ST"],
          "occupation": ["Farmer", "Student"]
        }
        
        "gender" options: "Male", "Female", "Other", "All".
        "category" options: "General", "OBC", "SC", "ST", "EWS", "Minority", "Muslim", "Sikh", "Christian", "Other caste/religion groups".
        "occupation" options: "Farmer", "Student", "Self-Employed", "Salaried", "Startup Founder", "Unemployed", "Laborer", "Business Owner", "Homemaker", "Senior Citizen".
        
        Translate English content to Hindi accurately.
        Do NOT invent fake schemes. If the scheme is not real or information is vague, return a JSON with empty fields or a "error" field explaining why.
      `;

      const result = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [{ role: 'user', parts: [{ text: `Draft scheme details for: ${schemeName}. Additional notes: ${prompt}` }] }],
        config: {
            systemInstruction: systemPrompt,
            responseMimeType: 'application/json'
        }
      });

      const responseText = result.text;
      if (!responseText) throw new Error('No response from AI');
      res.json(JSON.parse(responseText));

    } catch (error: any) {
      console.error('AI Error:', error);
      res.status(500).json({ error: 'Failed to generate draft', details: error.message });
    }
  });

  // Vite middleware
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
